# Comparative ESG report, observation date 9 October 2026

This compares Patagonia, UNIQLO through Fast Retailing Group, and H&M Group using fixed official excerpts and an independent FLA summary. Corporate disclosures establish reported quantities; FLA evaluates management systems. External rating and company-disclosure supplements appear below; important rating and investigation gaps remain.

## Legal entities and reporting boundaries

H & M Hennes & Mauritz AB is the legal entity described as H&M Group/H&M. Ramsbury Invest AB is formally its parent; Stefan Persson and family through Ramsbury/private holdings held 81.9% of votes and 61.8% of shares at 30 November 2024, excluding treasury shares. [hm2024]

Patagonia, Inc. sits within Patagonia Works, the holding company for Patagonia, Inc. and GPIW. In 2022 ownership transferred to Patagonia Purpose Trust (all voting stock, 2% of total) and Holdfast Collective (all non-voting stock, 98%). The Trust protects the company's purpose and controls governance. FY25 reporting excludes Patagonia Provisions and Fletcher Chouinard Designs. [patagonia2025]

UNIQLO Co., Ltd. is named in the report; Fast Retailing Co., Ltd. is the holding/parent company of the reporting group, whose brands include UNIQLO, GU and Theory. The excerpts support group affiliation but do not establish the exact subsidiary ownership percentage. [frfinance2024]

## Weighted assessment and calculation

The 0-10 metric inputs below are frozen analyst judgments from an earlier draft, not source-reproducible measurements or statistically calibrated scores. In particular, audit-evidence scores are not audited-factory percentages. Unknown outcomes cannot be inferred from a zero evidence score. All inputs and weights remain visible; no weights are redistributed. Earlier threshold explanations and arbitrary post-calculation adjustments are removed. The values 7.0 and 9.9 remain only as disclosed subjective inputs, not as results of the earlier 7.9 and 8.8 examples.

Environmental impact receives 40% because apparel production and energy materially affect climate and resources; worker impacts receive 35% because wages, safety and labor rights are central stakeholder concerns; transparency receives 25% because disclosure and verification determine how confidently the other claims can be assessed. These are explicit analyst priorities, not weights prescribed by an external standard. Within-category weights prioritize climate trends (70% of E), audit evidence and wages (70% of S), and supplier disclosure (40% of T). Since some inputs are unsupported judgments, the ranking illustrates the declared framework rather than demonstrating objective ethical superiority.

For brand b and category k, C[b,k] = sum_i(w[k,i]*s[b,k,i]); metric weights within each category sum to 1. Composite[b] = .40*C[b,E] + .35*C[b,S] + .25*C[b,T]. Every operation below is calculated locally with decimal arithmetic, without score rounding before summation.

| Category | Analyst metric input | Within-category weight | Patagonia | Fast Retailing | H&M |
|---|---|---|---|---|---|
| E | Scope1+2 trend judgment | 40.0% | 6 | 8 | 7 |
| E | Scope3 trend judgment | 30.0% | 4 | 6 | 5 |
| E | Renewable electricity judgment | 20.0% | 9.8 | 9.4 | 9.6 |
| E | Materials judgment | 10.0% | 8.4 | 1.8 | 8.9 |
| S | Audit-evidence judgment | 40.0% | 5 | 7 | 6.4 |
| S | Living-wage judgment | 30.0% | 5 | 0 | 0 |
| S | Grievance judgment | 20.0% | 10 | 5 | 10 |
| S | Forced-labor judgment | 10.0% | 10 | 10 | 5 |
| T | Supplier-disclosure judgment | 40.0% | 0 | 0 | 9.9 |
| T | Data-completeness judgment | 30.0% | 7 | 5 | 10 |
| T | Third-party-verification judgment | 30.0% | 10 | 5 | 5 |

| Category | Patagonia roll-up | Fast Retailing roll-up | H&M roll-up |
|---|---|---|---|
| E | 6*.4 + 4*.3 + 9.8*.2 + 8.4*.1 = 6.4000 | 8*.4 + 6*.3 + 9.4*.2 + 1.8*.1 = 7.0600 | 7*.4 + 5*.3 + 9.6*.2 + 8.9*.1 = 7.1100 |
| S | 5*.4 + 5*.3 + 10*.2 + 10*.1 = 6.5000 | 7*.4 + 0*.3 + 5*.2 + 10*.1 = 4.8000 | 6.4*.4 + 0*.3 + 10*.2 + 5*.1 = 5.0600 |
| T | 0*.4 + 7*.3 + 10*.3 = 5.1000 | 0*.4 + 5*.3 + 5*.3 = 3.0000 | 9.9*.4 + 10*.3 + 5*.3 = 8.4600 |

| Rank | Brand | E*.40 | S*.35 | T*.25 | Composite | Sensitivity E*.50+S*.30+T*.20 |
|---|---|---|---|---|---|---|
| 1 | H&M | 2.8440 | 1.7710 | 2.1150 | 6.7300 | 6.7650 |
| 2 | Patagonia | 2.5600 | 2.2750 | 1.2750 | 6.1100 | 6.1700 |
| 3 | Fast Retailing | 2.8240 | 1.6800 | 0.7500 | 5.2540 | 5.5700 |

Alternative weights retain the ordering; robustness to subjective inputs, missing evidence, boundaries or fiscal years is unestablished.

## Environmental evidence and trends

H&M fiscal years end 30 November; Patagonia FY25 is 1 May 2024-30 April 2025 and excludes Patagonia Provisions and Fletcher Chouinard Designs; Fast Retailing fiscal years end August. Native-currency revenue intensities support within-company trends, not directly comparable cross-company magnitudes. No FX conversion, inflation adjustment or constant-currency rebasing is applied. Percentages below are calculated from displayed rounded values. [hm2024; patagonia2025; frfinance2024]

| Series and boundary | Earliest | Middle | Latest | Latest versus earliest |
|---|---|---|---|---|
| H&M Scope1, tCO2e/MSEK, FY22/23/24 | .08 | .07 | .06 | -25.00% |
| H&M market-based Scope2, same years/unit | .21 | .17 | .11 | -47.62% |
| H&M reported "Total scope3 emissions intensity", same | 42.2 | 35.6 | 37.2 | -11.85%; +4.49% since FY23 |
| H&M reported "including use-phase" intensity, same | 34.0 | 28.6 | 29.7 | -12.65% |
| Patagonia total market-based, tCO2e/million USD, FY17/24/25 | 153.85 | 118.96 | 124.25 | -19.24%; +4.45% since FY24 |
| FR Scope1+2 market-based, tCO2e/million JPY, FY21/22/23 | .131271 | .069531 | .032531 | -75.22% |
| FR production Scope3, same years/unit | 1.819041 | 1.694825 | 1.351861 | -25.68% |

H&M source intensity labels conflict with the accompanying absolute Scope3 ordering; retain their literal labels and do not infer an unsupported explanation. Its absolute FY24 Scope1/market-Scope2 are 15,102/26,553 tCO2e; Scope3 excluding/including use-phase is 6,955,000/8,729,000. Methods changed in 2024; Scope1/2 have reporting/estimation limits, and Scope3 is rounded to thousands. [hm2024]

Patagonia supplies three nonconsecutive observations, with seven years between FY17 and FY24; there is no continuous three-year normalized series. FY25 Scope1/location-Scope2/market-Scope2/Scope3 are 1,335/3,441/93/181,218 tCO2e. FY17 location-Scope2 is 2,893, not 2,930 (the market-based value). FY17/FY24 inventories have reasonable assurance; FY25 assurance is pending and business-travel methodology changed. This compact baseline omitted revenue and disaggregated FR scopes now supplied in the archive supplement; its earlier production-only Scope3 series remains separately labeled. [patagonia2025; fr2024; frfinance2024]

| Renewable evidence | Current scope and quantity | Commitment and timing |
|---|---|---|
| H&M [hm2024] | Own-operation renewable electricity 96% FY24 (92/94% FY22/23); facility-type split unavailable | 100% by 2030, at least 50% new-generation PPAs; garment production spinning-to-finished-product 100% by 2030; coal phaseout 2026 |
| Patagonia [patagonia2025] | Owned/operated offices/facilities renewable electricity 98% FY24/25; total-energy renewable share 38/60/59% FY23/24/25 | 100% electricity goal for global owned/operated Scope2 footprint; renewable completion deadline undisclosed; supports separate 2030 climate targets |
| FR [frclimate2025] | Stores/offices renewable electricity 93.5% FY25 | 100% at all stores/major offices worldwide FY2030; supply-chain renewable-energy roadmap at least 70% FY2030 |

With a five-year short horizon from October 2026, 2030 commitments are short-term; the 2026 H&M coal target is immediate, not a renewable percentage. These are official statements. Patagonia lists solar, PPAs, utility products and unbundled electricity; FR uses solar PPAs, green products and certificates. Source-specific future percentages beyond H&M's PPA commitment are unavailable. [hm2024; patagonia2025; frclimate2025]

Materials: H&M 89% recycled/sustainably sourced FY24; Patagonia 84% preferred by purchased weight FY25; FR 18.2% low-GHG overall/47.4% polyester FY24. Definitions differ. H&M Tier1+2 recycled-water share is 12.2/16.0/19.6% FY22/23/24 and freshwater reduction is 9.5% versus FY22. Water-per-garment/revenue denominators and quantitative water data for Patagonia/FR are unavailable. [hm2024; patagonia2025; fr2024]

## Supply-chain ethics and transparency

Tier1 means final assembly; Tier2 includes fabric/dyeing/finishing. H&M FY24 FSLM participation is 739 (71% of Tier1 factories)/543 (56% Tier2); third-party verification is 690 (93% of participants)/510 (94%). FSLM participation is not a conventional audit-coverage percentage, and exact audited-factory percentages for BOTH tiers are unavailable. Disclosed supplier lists have 1,163/448 factories and cover 99/77% relevant production volume; those factory counts cannot be verification denominators. [hm2024]

Patagonia Tier1 and Tier2 audit percentages are each unavailable. FLA scores exceed 95% on six management-system principles evaluated in 2023-24; this is not factory coverage. Confidential grievance follow-up timelines and Better Work gap analysis need improvement. Living-wage attainment is 39% of in-scope factories in 2024 (over 65,000 workers), with 29% reaching at least 80% of living wage. Factory counts for the living-wage denominator are unavailable. [fla2025; patagonia2025]

FR Tier1 and Tier2 audit percentages are each unavailable. FY24 garment-factory grade counts are 422/63/6 for no-important-issue/important-issue/zero-tolerance categories, versus 417/85/14 FY23. Parentheses identify UNIQLO subset counts; the overall supplier-base denominator and tier split are unavailable. [fr2024]

| Inspected/as-reported scope | H&M | Patagonia | FR |
|---|---|---|---|
| Safety; wages/overtime | LoC categories: fire/emergency; compensation/minimum wage/overtime | FLA systems; detailed inspected checklist unavailable | Building safety; long hours, overtime pay, statutory leave and wages |
| Subcontracting/forced labor | Undeclared-unit LoC; child-labor category; forced-labor inspection detail unavailable | Detailed inspection scope unavailable | Forced-labor zero-tolerance; subcontracting detail unavailable |
| Environmental | Water/wastewater and energy/chemicals LoC categories; precise inspection protocol unavailable | Wastewater/chemical inspection details unavailable | Wastewater/chemical inspection details unavailable |

H&M FY24 Tier1+2 minimum-requirement noncompliance: social 522/environmental 280/business-practice 15/other 87; eight relationship terminations, 36 LoC versus 96 FY23. Most findings were remediated within two weeks; categories do not establish tier-specific inspection frequency. H&M has Tier1 guidelines, NMCs in five countries, Bangladesh RSC hotline and digital channels/pilots. The archive supplement adds H&M grievance coverage/outcomes; FR detailed outcomes remain unavailable. [hm2024; fr2024; fla2025]

Disclosure frequency: H&M annual report; FR annual integrated report/current climate page; Patagonia FY25 report, with repeated annual publication not established here. Supplier-list volume coverage is supplied only for H&M; Patagonia/FR list coverage is unavailable, not proof that no list exists. FR self-reports CDP A-list two consecutive years; this is different from FLA scores, GHG assurance and undisclosed MSCI/Sustainalytics/FTI ratings. Further disclosed cases and partial ratings follow; external investigation gaps remain. [hm2024; fr2024; frclimate2025; patagonia2025; fla2025]

## Worked normalization, without discretionary adjustments

Environmental: FR FY21 stores/main-offices Scope1+2 market-based intensity = (2.8*100,000 tCO2e)/(2,132,992 million JPY consolidated revenue) = .131271 tCO2e/million JPY; FY22/FY23 use 160,000/2,301,122 and 90,000/2,766,557. No FX/inflation adjustment. H&M Scope1+2 reported-intensity sum is .29/.24/.17 FY22/23/24; no invented FY22 revenue. [fr2024; frfinance2024; hm2024]

Ethics: H&M FY24 Tier1 verified-participant rate = 690 third-party-verified factories/739 FSLM participants*100 = 93.3694%; Tier2 = 510/543*100 = 93.9227%. Scope is participants of the respective tier, NOT all factories; FX/inflation is inapplicable. [hm2024]

Transparency: H&M FY24 disclosed-volume coverage = disclosed relevant production volume/total relevant production volume*100, source-reported 99% Tier1 and 77% Tier2. Raw volume numerators/denominators are unavailable. A defined equal-tier disclosure index = (99+77)/(100+100)*100 = 88%; numerator is 176 reported percentage-points, denominator is the 200-point full-disclosure maximum, not factory counts or aggregate production volume. FX/inflation is inapplicable. This measured index is distinct from the frozen 9.9 subjective disclosure input. [hm2024]

## Additional archived evidence

### Common reporting year and stronger climate boundaries

Scope1 means direct operations emissions; Scope2 purchased electricity/heat/steam (market and location accounting differ); Scope3 other value-chain emissions. FY2024 is the common label below, not identical calendar periods. Patagonia ends April, FR August and H&M November. Amounts are tCO2e. [hm2024; patagonia2025; frclimate2025]

| FY2024 | Scope1 | Scope2 location | Scope2 market | Scope3 |
|---|---:|---:|---:|---|
| H&M | 15,102 | 364,693 | 26,553 | 8,729,000 including use-phase; SBT exclusion 6,955,000 |
| Patagonia | 1,363 | 3,711 | 117 | 176,955 |
| FR Group | 8,760 | 297,360 | 43,154 | 5,198,890 calculated sum of disclosed categories |

FR FY24 Scope3 sum = 3,630,293+6,392+644,578+87,429+14,680+54,031+475+759,664+1,348. Categories marked not relevant or '-' contribute no reported quantity; the UNIQLO/GU target subset 3,389,624 is already contained in Category1 and is not added again. The sum is analyst-calculated from all disclosed categories, not a claimed source-published total. FY25 Scope1/location-Scope2/market-Scope2 are 9,301/301,434/20,906. FY25 categories marked with a star are assured by KPMG AZSA Sustainability Co., Ltd. Revised factors from FY22 and FY25 leased-asset/factor changes affect trend comparability. [frclimate2025]

Matched reported net revenue: H&M FY22/23/24 = 223,553/236,035/234,478 MSEK; Patagonia FY23/24/25 = 1,568/1,500/1,470 million USD (rounded); FR FY22/23/24 = 2,301,122/2,766,557/3,103,836 million JPY. No FX or inflation conversion. Patagonia FY24/25 Scope1 intensities .908667/.908163, market-Scope2 .078000/.063265, and Scope3 117.970000/123.277551 tCO2e/million USD: emissions growth concentrates in Scope3, which rises 4.50%. FY23 emissions remain unavailable; no continuous three-year series is claimed. [hm2024; patagonia2025; frfinance2024]

FR FY22/23/24 separate Scope1 intensities .004232/.003455/.002822, market-Scope2 .069117/.030906/.013903, and calculated all-disclosed-Scope3 2.494814/1.957650/1.674989 tCO2e/million JPY. Own-operation Scope1 and market-Scope2 decline; value-chain intensity also declines, subject to factor/boundary caveats. [frclimate2025; frfinance2024]

### Resources, materials and waste

Renewable share FY22/23/24/25: FR electricity 42.4/67.6/84.7/93.5%; yearly changes +25.2/+17.1/+8.8 percentage-points. H&M FY22/23/24 electricity 92/94/96% (+2/+2 points); Patagonia FY23/24/25 total-energy renewable 38/60/59% (+22/-1 points). Electricity and total energy differ, so the figures are not a shared cross-company measure. [frenergy; hm2024; patagonia2025]

H&M uses WWF's Water Risk Filter, contextual basin targets, water meters and functional effluent-treatment plants; withdrawal totals, water-stress volume shares and per-unit intensities remain unavailable. Patagonia/FR quantitative water footprints and comparable risk scores remain unavailable. H&M's recycled-water shares +3.8/+3.6 points FY22-FY24 show reuse progress, but a percentage alone cannot establish absolute watershed impact. [hm2024]

H&M defines recycled/sustainably sourced materials as meeting its sourcing requirements and aligning with Textile Exchange's preferred-fiber definition: consistently reduced impacts/increased benefits for climate, nature and people versus conventional equivalents. Reported commercial material percentages apply to shell fabric, excluding fillings, linings and trims; waste-weight-factor updates affect historical comparability. Total share FY22/23/24 is 82/83/89%; recycled 24/27/29.5%; recycled polyester 75/79/94%. Certifications include organic/recycled/Better Cotton, RMS, RWS, GCS and FSC/PEFC. Complete linked sourcing rules are not in these excerpts. [hm2024]

Patagonia's official preferred definition adds a holistic transformation of production systems to the Textile Exchange reduced-impact/increased-benefit standard, with most preferred materials backed by rigorous third-party social/animal/environmental certifications. Its chart labels 2023/24/25 preferred materials 81.4/83.2/84.1%, including fabrics and trims/BOM weight; yearly improvement is +1.8/+0.9 points. These boundaries differ from H&M shell-only reporting. [patagonia2025]

FR defines lower-impact classification through qualitative/quantitative GHG, water, biodiversity, human-rights and animal-welfare standards and aims to identify the materials best meeting them; the complete finalized taxonomy is unavailable. The 2024 report says 18.2% overall/47.4% polyester, while the current climate page says FY24 15.9/41.5 and FY25 19.4/46.4%, using previous Fall/Winter/current Spring/Summer collections. Preserve the different vintages/definitions instead of silently joining them. Three comparable annual FR material observations remain unavailable. [fr2024; frclimate2025]

H&M own-operation packaging reuse/recycling FY22/23/24 is 92/90/93%, disposal 8/10/7%. FY24 product waste is .7% of commercial-product weight, 95% reused/recycled, but prior two years are N/A. Packaging includes distribution-centre transport, return, product and pallet materials. Comparable three-year Patagonia/FR waste-diversion data are unavailable; Scope3 Category5 tCO2e is not waste tonnage. [hm2024]

### Wages, forced labor, grievances and disclosed cases

Patagonia's ten-year roadmap aimed at living wages in every factory by 2025; the report expects not to reach 100%. The 2024 39% attainment figure concerns in-scope factories, not all 65,000+ workers individually; Tier1/Tier2 worker splits and verified wage-program coverage counts are unavailable. H&M seeks normal-hour wages meeting basic needs/discretionary income via wage management, collective bargaining and responsible purchasing; a comparable time-bound all-factory attainment target/verified tier worker counts are unavailable. FR commits to living wages in its supply chain, but deadline and verified tier worker coverage are unavailable. [patagonia2025; hm2024; frfinance2024]

H&M prohibits cotton from Turkmenistan and Syria; this is a raw-material restriction, not a whole-country ban on every sourcing category. Comparable Patagonia/FR country-wide blacklist disclosures are unavailable. H&M disclosed four forced-labor cases FY24 (three forced overtime, one uniform deposit requiring one-year service; Tier1 three/Tier2 one), versus three FY23/one FY22. Suppliers refunded deposits, made overtime voluntary with individual consent and strengthened grievance systems; H&M reports resolution and ongoing follow-up. This differs from its NMC channel's zero forced-labor complaints and cannot be generalized to no forced labor. [hmslavery]

Patagonia describes recruitment-fee audits and leading fabric suppliers eliminating new fees by 2020, saving approximately 3,000 workers $1.7m annually; a 2022 Thailand/Taiwan survey of over 1,600 workers found 3% still owed fees. FY24 workweek averaged 54 hours with nine noncompliance instances (five excessive monthly overtime, one missing weekly rest, three inadequate breaks); each had remediation/long-term solutions. These are corporate reports, not independent findings. FR FY24 six factories had zero-tolerance violations, three confirmed improvements; issue categories include forced/child labor, without claiming all six involved forced labor. [patagonia2025; frfinance2024]

H&M Speak Up allows anonymity subject to local law and prohibits retaliation; FSLM-scope grievance mechanisms FY24 cover 100% Tier1/99.61% Tier2, not all-factory coverage. NMC outcomes: seven unresolved from FY23, fourteen new, twenty resolved, one carried forward; resolving 20/21 available cases is 95.2381%, not 20/14 new cases. Multilingual/no-cost access, substantiation share and closure days are unavailable. Patagonia has multiple channels including confidentiality, but FLA recommends follow-up timelines; tier coverage/accessibility/outcomes are unavailable. FR accessible channel operation, tier coverage and outcome counts remain unavailable. [hm2024; fla2025]

B Lab's December 2023 company-disclosure report describes Patagonia's California wage/hour class-action allegation, disputed by the company and settled to avoid litigation costs; settlement was less than 1% of revenue and court approval was pending at publication. This is B Lab-published company disclosure, not an independent investigation or an exact cash fine. Reported timekeeping review is the response. Comparable qualifying external H&M/FR controversy financial consequences and source-backed stock/sales attribution are unavailable. [blabdisclosure]

### External ratings and triangulation

FR's updated company page reports February2025 Sustainalytics LowRisk (numeric0-100 score unavailable), 2025 CDP climate/water A and forest B, and ISS Prime since2024; MSCI index inclusion is not an MSCI alphabetical ESG rating. H&M's25September2025 company announcement reports What Fuels Fashion2025 rank1/200 and71%, explicitly a decarbonization-transparency score, not FTI or overall ethical performance. B Lab's Patagonia profile reports166.0 overall with governance17.8/workers23.7/community79.2/environment40.4/customers4.7; 2020score151.4 is historical. Its current assessment issue month is unavailable. [frratings; hmwff; bcorp]

FTI2023's archived methodology evaluates public disclosure; it is older than the requested current/previous-year vintage and supplies no full three-brand/five-category scores here. For all brands, current MSCI grade/date, complete Sustainalytics score/category and current FTI overall/five-section scores remain incomplete. Ratings measure different constructs/vintages: BCorp system impact, FLA labor management, Sustainalytics unmanaged financial risk, CDP environmental disclosure, and WFF decarbonization transparency. They do not justify pooling point scores. No frozen analyst score is recalibrated from these additions; rating divergence remains partly untestable rather than invented. [fti2023; frratings; hmwff; bcorp; fla2025]

## Sources

- [hm2024] H&M Group Annual and Sustainability Report 2024. March 2025; FY2024. https://hmgroup.com/wp-content/uploads/2025/03/HM-Group-Annual-and-sustainability-report-2024.pdf
- [patagonia2025] Patagonia Work in Progress Report 2025. November 2025; FY25 May 2024-April 2025. https://www.patagonia.com/media/pdf/patagonia-progress-report-2025.pdf
- [fr2024] Fast Retailing Integrated Report 2024 sustainability chapter. 2024; FY2023 and FY2024 explicitly labelled. https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en_06.pdf
- [frfinance2024] Fast Retailing Integrated Report 2024. 2024; FY2024. https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en.pdf
- [frclimate2025] Fast Retailing Response to Climate Change. current page; FY2025. https://www.fastretailing.com/eng/sustainability/environment/climatechange.html
- [fla2025] Patagonia Post-Accreditation Report 2025. September 2025; 2023-2024 evaluations. https://www.fairlabor.org/wp-content/uploads/2025/09/Patagonia_Post-Accreditation-Report_2025.pdf

- [frenergy] Fast Retailing Improved Energy Efficiency. 19 March 2026 update; FY2022-FY2025. https://www.fastretailing.com/eng/sustainability/environment/energy.html
- [frratings] Fast Retailing Evaluation by Society. 3 September 2026 update. https://www.fastretailing.com/eng/sustainability/report/evaluation.html
- [hmslavery] H&M Group Modern Slavery Statement 2024. 2024 reporting year; 2025 publication. https://hmgroup.com/wp-content/uploads/2025/03/HM-Group-Modern-slavery-statement-2024.pdf
- [bcorp] B Lab Patagonia Certified B Corporation assessment. Current archived page; links to 2024 disclosures. https://www.bcorporation.net/en-us/find-a-b-corp/company/patagonia-inc/
- [blabdisclosure] Patagonia Works Disclosure Report. Submitted December 2023; B Lab. https://s3.amazonaws.com/blab-impact-published-production/FwqEOpz9x13JdhDqn2Lxp35D5iY6Zoht
- [hmwff] H&M ranks 1st in Fashion Revolution's What Fuels Fashion? Report. 25 September 2025. https://hmgroup.com/news/hm-ranks-1st-in-fashion-revolutions-what-fuels-fashion-report/
- [fti2023] Fashion Transparency Index 2023 findings. 2023. https://www.fashionrevolution.org/fashion-transparency-index-2023/

## Small chart

FR Scope1+2 intensity, tCO2e/million JPY; 1 # approximately .02. [fr2024; frfinance2024]

```text
FY21 ####### .131271
FY22 ###     .069531
FY23 ##      .032531
```
