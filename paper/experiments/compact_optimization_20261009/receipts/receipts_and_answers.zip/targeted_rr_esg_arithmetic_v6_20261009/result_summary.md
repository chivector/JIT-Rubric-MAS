# ESG targeted repair, 9 October 2026

Task: `6847465956a0f6376a60543e` (Patagonia / UNIQLO-Fast Retailing / H&M).

| Candidate | Evaluation scope | Score | Generation | Evaluation |
|---|---|---:|---:|---:|
| Historical answer | All 28 native criteria | 0.0645161290 | Historical run | Historical run |
| Compact v3 | Fixed seven criteria | 0.3846153846 | 1 call / 18,948 tokens | 7 calls / 64,629 tokens |
| Compact v5 | Same fixed seven criteria | 0.5000000000 | 1 call / 15,175 tokens | 7 calls / 35,246 tokens |
| Arithmetic v6 | Same fixed seven criteria | 1.0000000000 | 0 new generation calls; reuses v5 | 7 calls / 33,564 tokens |
| Arithmetic v6 | All 28 unchanged native criteria | 0.2795698925 | 0 new generation calls; reuses v5 | 28 calls / 133,236 tokens |

All v5/v6 evaluations above are complete. The full score is for this single ESG task; it is not an RR dataset average. The native full score has a positive-weight denominator of 93. Passing criteria have total weight 26. No negative-weight fault was triggered. The native evaluator and private record remain unchanged.

V5 generation used 11,326 input and 3,849 output tokens, finishing with `stop`. Its 1,945 whitespace words exceeded the 1,800-word prompt goal, but the answer was not truncated. V6 is a complete local rendering of 1,815 whitespace words, with one small ASCII chart; it adds no model generation or source-retrieval calls. V5 and every older output remain preserved.

The local repair freezes and explicitly labels v5's metric inputs as subjective analyst judgments. It corrects category roll-ups, weighted contributions, sensitivity calculations and ranking using decimal arithmetic, removes unsupported threshold explanations, fixes source transcription errors, and supplies actual normalization examples. It does not establish the frozen scores as empirical measurements. Correctly calculated totals are H&M 6.7300, Patagonia 6.1100 and Fast Retailing 5.2540; the native rubric's separate required Patagonia-first ranking is not met.

The seven passed criteria cover current/future renewable data, available normalized climate trends, a chart, tier-specific audit disclosure gaps, reproducible weighted arithmetic and worked normalization in each pillar. The full assessment still fails important source/coverage requirements: legal entities, common-year disaggregated emissions, all-company water metrics, official material definitions and waste trends, cross-company normalized metrics, brand-specific living-wage commitments, high-risk sourcing bans, external investigations and financial consequences, grievance outcomes, current FTI/MSCI/Sustainalytics data and rating divergences.

Further progress requires evidence for these remaining fields and a source-reproducible scoring-input method. Repeating free-form generation against the same excerpts is unlikely to fill those gaps. See `source_verification.json`, `calculations.json`, `report.json` and `full_report.json` for the evidence and calculations.
