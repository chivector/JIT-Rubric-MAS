# Comparative ESG report, observation date 9 October 2026

This compares Patagonia, UNIQLO through Fast Retailing Group, and H&M Group using fixed official excerpts and an independent FLA summary. Corporate disclosures establish reported quantities; FLA evaluates management systems. MSCI, Sustainalytics and Fashion Transparency Index scores, external investigations and company responses to controversies are unavailable in these excerpts.

## Weighted assessment and calculation

The 0-10 metric inputs below are frozen analyst judgments from an earlier draft, not source-reproducible measurements or statistically calibrated scores. In particular, audit-evidence scores are not audited-factory percentages. Unknown outcomes cannot be inferred from a zero evidence score. All inputs and weights remain visible; no weights are redistributed. Earlier threshold explanations and arbitrary post-calculation adjustments are removed. The values 7.0 and 9.9 remain only as disclosed subjective inputs, not as results of the earlier 7.9 and 8.8 examples.

Environmental impact receives 40% because apparel production and energy materially affect climate and resources; worker impacts receive 35% because wages, safety and labor rights are central stakeholder concerns; transparency receives 25% because disclosure and verification determine how confidently the other claims can be assessed. These are explicit analyst priorities, not weights prescribed by an external standard. Within-category weights prioritize climate trends (70% of E), audit evidence and wages (70% of S), and supplier disclosure (40% of T). Since some inputs are unsupported judgments, the ranking illustrates the declared framework rather than demonstrating objective ethical superiority.

For brand b and category k, C[b,k] = sum_i(w[k,i]*s[b,k,i]); metric weights within each category sum to 1. Composite[b] = .40*C[b,E] + .35*C[b,S] + .25*C[b,T]. Every operation below is calculated locally with decimal arithmetic, without score rounding before summation.

| Category | Analyst metric input | Within-category weight | Patagonia | Fast Retailing | H&M |
|---|---|---|---|---|---|
| E | Scope1+2 trend judgment | 40.0% | 6 | 8 | 7 |
| E | Scope3 trend judgment | 30.0% | 4 | 6 | 5 |
| E | Renewable electricity judgment | 20.0% | 9.8 | 9.4 | 9.6 |
| E | Materials judgment | 10.0% | 8.4 | 1.8 | 8.9 |
| S | Audit-evidence judgment | 40.0% | 5 | 7 | 6.4 |
| S | Living-wage judgment | 30.0% | 5 | 0 | 0 |
| S | Grievance judgment | 20.0% | 10 | 5 | 10 |
| S | Forced-labor judgment | 10.0% | 10 | 10 | 5 |
| T | Supplier-disclosure judgment | 40.0% | 0 | 0 | 9.9 |
| T | Data-completeness judgment | 30.0% | 7 | 5 | 10 |
| T | Third-party-verification judgment | 30.0% | 10 | 5 | 5 |

| Category | Patagonia roll-up | Fast Retailing roll-up | H&M roll-up |
|---|---|---|---|
| E | 6*.4 + 4*.3 + 9.8*.2 + 8.4*.1 = 6.4000 | 8*.4 + 6*.3 + 9.4*.2 + 1.8*.1 = 7.0600 | 7*.4 + 5*.3 + 9.6*.2 + 8.9*.1 = 7.1100 |
| S | 5*.4 + 5*.3 + 10*.2 + 10*.1 = 6.5000 | 7*.4 + 0*.3 + 5*.2 + 10*.1 = 4.8000 | 6.4*.4 + 0*.3 + 10*.2 + 5*.1 = 5.0600 |
| T | 0*.4 + 7*.3 + 10*.3 = 5.1000 | 0*.4 + 5*.3 + 5*.3 = 3.0000 | 9.9*.4 + 10*.3 + 5*.3 = 8.4600 |

| Rank | Brand | E*.40 | S*.35 | T*.25 | Composite | Sensitivity E*.50+S*.30+T*.20 |
|---|---|---|---|---|---|---|
| 1 | H&M | 2.8440 | 1.7710 | 2.1150 | 6.7300 | 6.7650 |
| 2 | Patagonia | 2.5600 | 2.2750 | 1.2750 | 6.1100 | 6.1700 |
| 3 | Fast Retailing | 2.8240 | 1.6800 | 0.7500 | 5.2540 | 5.5700 |

Alternative weights retain the ordering; robustness to subjective inputs, missing evidence, boundaries or fiscal years is unestablished.

## Environmental evidence and trends

H&M fiscal years end 30 November; Patagonia FY25 is 1 May 2024-30 April 2025 and excludes Patagonia Provisions and Fletcher Chouinard Designs; Fast Retailing fiscal years end August. Native-currency revenue intensities support within-company trends, not directly comparable cross-company magnitudes. No FX conversion, inflation adjustment or constant-currency rebasing is applied. Percentages below are calculated from displayed rounded values. [hm2024; patagonia2025; frfinance2024]

| Series and boundary | Earliest | Middle | Latest | Latest versus earliest |
|---|---|---|---|---|
| H&M Scope1, tCO2e/MSEK, FY22/23/24 | .08 | .07 | .06 | -25.00% |
| H&M market-based Scope2, same years/unit | .21 | .17 | .11 | -47.62% |
| H&M reported "Total scope3 emissions intensity", same | 42.2 | 35.6 | 37.2 | -11.85%; +4.49% since FY23 |
| H&M reported "including use-phase" intensity, same | 34.0 | 28.6 | 29.7 | -12.65% |
| Patagonia total market-based, tCO2e/million USD, FY17/24/25 | 153.85 | 118.96 | 124.25 | -19.24%; +4.45% since FY24 |
| FR Scope1+2 market-based, tCO2e/million JPY, FY21/22/23 | .131271 | .069531 | .032531 | -75.22% |
| FR production Scope3, same years/unit | 1.819041 | 1.694825 | 1.351861 | -25.68% |

H&M source intensity labels conflict with the accompanying absolute Scope3 ordering; retain their literal labels and do not infer an unsupported explanation. Its absolute FY24 Scope1/market-Scope2 are 15,102/26,553 tCO2e; Scope3 excluding/including use-phase is 6,955,000/8,729,000. Methods changed in 2024; Scope1/2 have reporting/estimation limits, and Scope3 is rounded to thousands. [hm2024]

Patagonia supplies three nonconsecutive observations, with seven years between FY17 and FY24; there is no continuous three-year normalized series. FY25 Scope1/location-Scope2/market-Scope2/Scope3 are 1,335/3,441/93/181,218 tCO2e. FY17 location-Scope2 is 2,893, not 2,930 (the market-based value). FY17/FY24 inventories have reasonable assurance; FY25 assurance is pending and business-travel methodology changed. Separate scope-specific annual revenue denominators are not supplied. FR supplies combined Scope1+2, not separate scopes; production Scope3 covers raw materials, fabric and garment manufacturing for UNIQLO/GU, whereas revenue is consolidated group revenue. [patagonia2025; fr2024; frfinance2024]

| Renewable evidence | Current scope and quantity | Commitment and timing |
|---|---|---|
| H&M [hm2024] | Own-operation renewable electricity 96% FY24 (92/94% FY22/23); facility-type split unavailable | 100% by 2030, at least 50% new-generation PPAs; garment production spinning-to-finished-product 100% by 2030; coal phaseout 2026 |
| Patagonia [patagonia2025] | Owned/operated offices/facilities renewable electricity 98% FY24/25; total-energy renewable share 38/60/59% FY23/24/25 | 100% electricity goal for global owned/operated Scope2 footprint; renewable completion deadline undisclosed; supports separate 2030 climate targets |
| FR [frclimate2025] | Stores/offices renewable electricity 93.5% FY25 | 100% at all stores/major offices worldwide FY2030; supply-chain renewable-energy roadmap at least 70% FY2030 |

With a five-year short horizon from October 2026, 2030 commitments are short-term; the 2026 H&M coal target is immediate, not a renewable percentage. These are official statements. Patagonia lists solar, PPAs, utility products and unbundled electricity; FR uses solar PPAs, green products and certificates. Source-specific future percentages beyond H&M's PPA commitment are unavailable. [hm2024; patagonia2025; frclimate2025]

Materials: H&M 89% recycled/sustainably sourced FY24; Patagonia 84% preferred by purchased weight FY25; FR 18.2% low-GHG overall/47.4% polyester FY24. Definitions differ. H&M Tier1+2 recycled-water share is 12.2/16.0/19.6% FY22/23/24 and freshwater reduction is 9.5% versus FY22. Water-per-garment/revenue denominators and quantitative water data for Patagonia/FR are unavailable. [hm2024; patagonia2025; fr2024]

## Supply-chain ethics and transparency

Tier1 means final assembly; Tier2 includes fabric/dyeing/finishing. H&M FY24 FSLM participation is 739 (71% of Tier1 factories)/543 (56% Tier2); third-party verification is 690 (93% of participants)/510 (94%). FSLM participation is not a conventional audit-coverage percentage, and exact audited-factory percentages for BOTH tiers are unavailable. Disclosed supplier lists have 1,163/448 factories and cover 99/77% relevant production volume; those factory counts cannot be verification denominators. [hm2024]

Patagonia Tier1 and Tier2 audit percentages are each unavailable. FLA scores exceed 95% on six management-system principles evaluated in 2023-24; this is not factory coverage. Confidential grievance follow-up timelines and Better Work gap analysis need improvement. Living-wage attainment is 39% of in-scope factories in 2024 (over 65,000 workers), with 29% reaching at least 80% of living wage. Factory counts for the living-wage denominator are unavailable. [fla2025; patagonia2025]

FR Tier1 and Tier2 audit percentages are each unavailable. FY24 garment-factory grade counts are 422/63/6 for no-important-issue/important-issue/zero-tolerance categories, versus 417/85/14 FY23. Parentheses identify UNIQLO subset counts; the overall supplier-base denominator and tier split are unavailable. [fr2024]

| Inspected/as-reported scope | H&M | Patagonia | FR |
|---|---|---|---|
| Safety; wages/overtime | LoC categories: fire/emergency; compensation/minimum wage/overtime | FLA systems; detailed inspected checklist unavailable | Building safety; long hours, overtime pay, statutory leave and wages |
| Subcontracting/forced labor | Undeclared-unit LoC; child-labor category; forced-labor inspection detail unavailable | Detailed inspection scope unavailable | Forced-labor zero-tolerance; subcontracting detail unavailable |
| Environmental | Water/wastewater and energy/chemicals LoC categories; precise inspection protocol unavailable | Wastewater/chemical inspection details unavailable | Wastewater/chemical inspection details unavailable |

H&M FY24 Tier1+2 minimum-requirement noncompliance: social 522/environmental 280/business-practice 15/other 87; eight relationship terminations, 36 LoC versus 96 FY23. Most findings were remediated within two weeks; categories do not establish tier-specific inspection frequency. H&M has Tier1 guidelines, NMCs in five countries, Bangladesh RSC hotline and digital channels/pilots. FR grievance-channel detail is unavailable; FLA confirms Patagonia's confidential channel. [hm2024; fr2024; fla2025]

Disclosure frequency: H&M annual report; FR annual integrated report/current climate page; Patagonia FY25 report, with repeated annual publication not established here. Supplier-list volume coverage is supplied only for H&M; Patagonia/FR list coverage is unavailable, not proof that no list exists. FR self-reports CDP A-list two consecutive years; this is different from FLA scores, GHG assurance and undisclosed MSCI/Sustainalytics/FTI ratings. Audit findings above are disclosed issues; external controversy histories and responses remain unavailable. [hm2024; fr2024; frclimate2025; patagonia2025; fla2025]

## Worked normalization, without discretionary adjustments

Environmental: FR FY21 stores/main-offices Scope1+2 market-based intensity = (2.8*100,000 tCO2e)/(2,132,992 million JPY consolidated revenue) = .131271 tCO2e/million JPY; FY22/FY23 use 160,000/2,301,122 and 90,000/2,766,557. No FX/inflation adjustment. H&M Scope1+2 reported-intensity sum is .29/.24/.17 FY22/23/24; no invented FY22 revenue. [fr2024; frfinance2024; hm2024]

Ethics: H&M FY24 Tier1 verified-participant rate = 690 third-party-verified factories/739 FSLM participants*100 = 93.3694%; Tier2 = 510/543*100 = 93.9227%. Scope is participants of the respective tier, NOT all factories; FX/inflation is inapplicable. [hm2024]

Transparency: H&M FY24 disclosed-volume coverage = disclosed relevant production volume/total relevant production volume*100, source-reported 99% Tier1 and 77% Tier2. Raw volume numerators/denominators are unavailable. A defined equal-tier disclosure index = (99+77)/(100+100)*100 = 88%; numerator is 176 reported percentage-points, denominator is the 200-point full-disclosure maximum, not factory counts or aggregate production volume. FX/inflation is inapplicable. This measured index is distinct from the frozen 9.9 subjective disclosure input. [hm2024]

## Sources

- [hm2024] H&M Group Annual and Sustainability Report 2024. March 2025; FY2024. https://hmgroup.com/wp-content/uploads/2025/03/HM-Group-Annual-and-sustainability-report-2024.pdf
- [patagonia2025] Patagonia Work in Progress Report 2025. November 2025; FY25 May 2024-April 2025. https://www.patagonia.com/media/pdf/patagonia-progress-report-2025.pdf
- [fr2024] Fast Retailing Integrated Report 2024 sustainability chapter. 2024; FY2023 and FY2024 explicitly labelled. https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en_06.pdf
- [frfinance2024] Fast Retailing Integrated Report 2024. 2024; FY2024. https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en.pdf
- [frclimate2025] Fast Retailing Response to Climate Change. current page; FY2025. https://www.fastretailing.com/eng/sustainability/environment/climatechange.html
- [fla2025] Patagonia Post-Accreditation Report 2025. September 2025; 2023-2024 evaluations. https://www.fairlabor.org/wp-content/uploads/2025/09/Patagonia_Post-Accreditation-Report_2025.pdf

## Small chart

FR Scope1+2 intensity, tCO2e/million JPY; 1 # approximately .02. [fr2024; frfinance2024]

```text
FY21 ####### .131271
FY22 ###     .069531
FY23 ##      .032531
```
