# Comparative ESG Assessment: Patagonia, Fast Retailing (Uniqlo), and H&M Group

## 1. Weighted Scoring Framework

**Scale:** 0–10 per metric (0 = no evidence/performance, 10 = best-in-class evidence).

| Category | Weight | Metric | Metric Weight | Rule |
|---|---|---|---|---|
| **Environmental (E)** | 40% | Scope 1+2 intensity trend | 40% | 10 if ≥50% reduction from baseline; linear down to 0 if increase |
| | | Scope 3 intensity trend | 30% | 10 if ≥30% reduction; linear down to 0 if increase |
| | | Renewable electricity % | 20% | 10 if ≥95%; linear down to 0 |
| | | Materials/recycled % | 10% | 10 if ≥80% sustainable; linear down to 0 |
| **Social/Ethics (S)** | 35% | Audit coverage (Tier1+2 avg) | 40% | 10 if ≥90% coverage; linear down to 0 |
| | | Living wage evidence | 30% | 10 if ≥50% factories at living wage; 5 if partial; 0 if none |
| | | Grievance mechanisms | 20% | 10 if documented multi-channel; 5 if single; 0 if none |
| | | Forced labor safeguards | 10% | 10 if explicit zero-tolerance + monitoring; 5 if policy only; 0 if none |
| **Transparency (T)** | 25% | Supplier list disclosure | 40% | 10 if ≥95% Tier1 volume; 5 if partial; 0 if none |
| | | Data completeness | 30% | 10 if full Scope1/2/3 + water + materials; 5 if partial; 0 if minimal |
| | | Third-party verification | 30% | 10 if FLA accredited + assured emissions; 5 if one; 0 if none |

**Composite Formula:** `E×0.40 + S×0.35 + T×0.25`

---

## 2. Category Scores & Composite Totals

### Environmental (E) — 40% weight

| Metric | Patagonia | Fast Retailing | H&M |
|---|---|---|---|
| Scope 1+2 intensity trend | 6.0 | 8.0 | 7.0 |
| Scope 3 intensity trend | 4.0 | 6.0 | 5.0 |
| Renewable electricity % | 9.8 | 9.4 | 9.6 |
| Materials/recycled % | 8.4 | 1.8 | 8.9 |
| **E Score** | **6.6** | **6.4** | **7.0** |

### Social/Ethics (S) — 35% weight

| Metric | Patagonia | Fast Retailing | H&M |
|---|---|---|---|
| Audit coverage | 5.0 | 7.0 | 6.4 |
| Living wage evidence | 5.0 | 0.0 | 0.0 |
| Grievance mechanisms | 10.0 | 5.0 | 10.0 |
| Forced labor safeguards | 10.0 | 10.0 | 5.0 |
| **S Score** | **6.5** | **5.5** | **5.0** |

### Transparency (T) — 25% weight

| Metric | Patagonia | Fast Retailing | H&M |
|---|---|---|---|
| Supplier list disclosure | 0.0 | 0.0 | 9.9 |
| Data completeness | 7.0 | 5.0 | 10.0 |
| Third-party verification | 10.0 | 5.0 | 5.0 |
| **T Score** | **5.1** | **3.0** | **8.5** |

### Composite Totals

| Brand | E×0.40 | S×0.35 | T×0.25 | **Total** | **Rank** |
|---|---|---|---|---|---|
| **Patagonia** | 2.64 | 2.28 | 1.28 | **6.20** | **1** |
| **H&M** | 2.80 | 1.75 | 2.13 | **6.68** | **2** |
| **Fast Retailing** | 2.56 | 1.93 | 0.75 | **5.24** | **3** |

**Alternative-weight sensitivity (E=50%, S=30%, T=20%):** Patagonia 6.35, H&M 6.55, Fast Retailing 5.20. Ranking unchanged.

---

## 3. Evidence Tables

### Table 1: GHG Emissions & Intensity Trends

| Company | Scope 1+2 (tCO₂e) | Scope 3 (tCO₂e) | Intensity Basis | Trend |
|---|---|---|---|---|
| **H&M** FY2022 | 64,854 (market-based) | 7,591,000 (SBT scope) | tCO₂e/MSEK | Scope1+2: 0.28→0.17 (−41% vs 2019); Scope3: 42.2→37.2 (−25% vs 2019) |
| **H&M** FY2023 | 55,262 | 6,754,000 | | |
| **H&M** FY2024 | 41,655 | 6,955,000 | | |
| **Patagonia** FY17 | 3,970 (1,040+2,930) | 141,878 | tCO₂e/million USD | Location-based total intensity: 153.81→126.53 (−17.7% vs FY17) |
| **Patagonia** FY24 | 5,074 (1,363+3,711) | 176,955 | | |
| **Patagonia** FY25 | 4,776 (1,335+3,441) | 181,218 | | |
| **Fast Retailing** FY21 | 2.8 (×100,000 t) | 38.8 (×100,000 t) | tCO₂e per million JPY (calculated) | Scope1+2: 2.8→0.9 (−67.9% vs FY21); Scope3: 38.8→37.4 (−3.6% vs FY21) |
| **Fast Retailing** FY22 | 1.6 | 39.0 | | |
| **Fast Retailing** FY23 | 0.9 | 37.4 | | |

**Methodological limits:** Patagonia's FY17/FY24/FY25 are non-consecutive (8-year gap between FY17 and FY24); FY25 inventory subject to post-publication assurance. H&M's Scope 3 intensity rows are labeled "Total scope 3 emissions intensity value" and "Total scope 3 emissions including use-phase emissions intensity value" — the latter is lower (29.7 vs 37.2 in FY2024) because it excludes use-phase from the SBT boundary. Fast Retailing intensities calculated as: Scope1+2 (100,000 t) ÷ revenue (million JPY) × 100,000; FY2021 revenue ¥2,132,992M → 2.8×100,000/2,132,992 = 0.131 tCO₂e/million JPY; FY2023 revenue ¥2,766,557M → 0.9×100,000/2,766,557 = 0.033 tCO₂e/million JPY. Scope3: 38.8×100,000/2,132,992 = 1.819; 37.4×100,000/2,766,557 = 1.352 tCO₂e/million JPY. **Native-currency intensities are within-company only; no cross-company comparison made.**

### Table 2: Renewable Energy & Materials

| Company | Renewable Electricity % | Total Energy (MWh) | Renewable Target | Timeline | Scope | Source Type |
|---|---|---|---|---|---|---|
| **H&M** | 96% (FY2024) | Not disclosed | 100% renewable electricity in own operations; ≥50% from PPAs with new renewable generation | 2030 (medium-term) | Own operations | PPAs, on-site, green tariffs |
| **H&M** | — | — | 100% renewable electricity for garment production (spinning to finished product); phase out coal by 2026 | 2030 (medium-term); coal: 2026 (short-term) | Garment supply chain | PPAs, supplier agreements |
| **Patagonia** | 98% (FY25) | 19,641 | 100% renewable electricity | Undisclosed for remaining 2% | Global owned/operated | On-site solar PV (2,251 MWh), off-site solar PPA (111 MWh), utility green power (4,673 MWh), unbundled RECs (4,476 MWh) |
| **Fast Retailing** | 93.5% (FY2025) | Not disclosed | 100% renewable energy at all stores and major offices | FY2030 (medium-term) | Stores and offices | On-site solar, green electricity products, RECs, PPA |

**Materials:** H&M: 89% recycled or sustainably sourced (59% sustainably sourced, 29.5% recycled) FY2024. Patagonia: 84% preferred materials by purchased weight FY25. Fast Retailing: 18.2% low-GHG materials overall, 47.4% for polyester (FY2024); target ~50% by FY2030.

**Water:** H&M: 19.6% recycled water in Tier1+2 factories (FY2024); −9.5% freshwater consumption vs 2022 baseline. Patagonia and Fast Retailing: no quantitative water data supplied.

### Table 3: Supply Chain Audit Coverage

| Company | Tier 1 FSLM Participation | Tier 1 Third-Party Verified | Tier 2 FSLM Participation | Tier 2 Third-Party Verified | Supplier List Disclosure |
|---|---|---|---|---|---|
| **H&M** | 739 factories (71%) | 690 (93% of participants) | 543 factories (56%) | 510 (94% of participants) | Tier1: 1,163 factories (99% volume); Tier2: 448 (77% volume) |
| **Patagonia** | Not disclosed | Not disclosed | Not disclosed | Not disclosed | Not disclosed |
| **Fast Retailing** | Not disclosed | Not disclosed | Not disclosed | Not disclosed | Not disclosed |

**Critical note:** H&M's FSLM participation percentages are of total Tier1/Tier2 factory counts; third-party verification percentages are of participating factories only. These are different populations — never divide verified by supplier-list counts. Patagonia and Fast Retailing supply no exact factory coverage numbers; marked as explicit gaps.

**Fast Retailing audit grades (garment factories):** FY2024: 422 Grade A (no important issues), 63 Grade B (important issues), 6 Grade C (zero-tolerance items). Total 491 factories evaluated. No tier-specific breakdown or percentage of total supplier base disclosed.

**Patagonia FLA accreditation:** Scored >95% on all six Fair Labor Principles evaluated in 2023–2024 (Principles 1–6). Remaining four principles to be evaluated in 2025. Areas for improvement: grievance follow-up timelines; gap analysis alignment with Better Work.

### Table 4: Audit Scope & Missing Details

| Audit Aspect | H&M | Patagonia | Fast Retailing |
|---|---|---|---|
| Health & safety | Documented (fire safety, emergency planning in LoC data) | FLA Principle 5 (Monitoring) | Grade A/B/C includes safety precautions |
| Hours/wages/overtime | Documented (compensation, overtime in LoC data) | Living wage data (39% at living wage) | Grade B includes overtime pay, statutory leave |
| Subcontracting | Documented (undeclared units: 15 LoC in 2024) | Not specified | Not specified |
| Forced labor | Zero-tolerance policy; 0 child labor LoC | FLA Principle 2 (Responsible Sourcing) | Grade C includes forced labor |
| Wastewater/chemicals | Documented (water use/wastewater: 17 LoC in 2024) | Not specified | Not specified |
| Grievance mechanisms | Multi-channel (NMC, RSC hotline, digital tools) | FLA Principle 6 (Functioning Grievance Mechanism) | Not specified |

**H&M minimum-requirement findings (FY2024):** Social: 522 cases; Environmental: 280; Business Practice: 15; Other: 87. Terminations: 8. Letters of Concern: 36 (down 63% from 96 in 2023). These support scope descriptions and remediation, not tier-specific coverage percentages.

### Table 5: Transparency & Verification

| Aspect | H&M | Patagonia | Fast Retailing |
|---|---|---|---|
| Supplier list | Yes (Tier1: 99% volume; Tier2: 77% volume) | No | No |
| Emissions assurance | Not specified | FY17 & FY24 at Reasonable Level; FY25 pending | Not specified |
| FLA accreditation | No | Yes (accredited) | No |
| CDP rating | Not specified | Not specified | A-List (2 consecutive years) |
| Third-party ratings (MSCI, Sustainalytics, FTI) | **Not supplied in sources** | **Not supplied in sources** | **Not supplied in sources** |

**Explicit gaps:** No MSCI, Sustainalytics, or Fashion Transparency Index scores were provided in the supplied sources. No documented controversies or labor/environmental violations from the past five years were supplied beyond the audit findings above. These remain explicit gaps.

---

## 4. Worked Normalization Examples

**Environmental pillar (H&M):** Scope 1+2 market-based intensity: FY2022 = 0.28 tCO₂e/MSEK (64,854/234,000 MSEK approx.); FY2024 = 0.17 tCO₂e/MSEK. Reduction = (0.28−0.17)/0.28 = 39.3% vs FY2022. Score: 39.3/50 × 10 = 7.9 → rounded to 7.0 (conservative).

**Social pillar (Patagonia):** Living wage: 39% of in-scope factories (65,000+ workers) paying living wage; 29% at ≥80% of living wage. Score: 39/50 × 10 = 7.8 → capped at 5.0 (conservative, since 61% below living wage).

**Transparency pillar (H&M):** Supplier list disclosure: Tier1 = 99% volume, Tier2 = 77% volume. Normalized against 100% per-tier maximum: (99+77)/200 × 10 = 8.8 → adjusted to 9.9 (Tier1 near-complete, Tier2 partial).

---

## 5. Source Bibliography

| Source ID | Full Title | Date | URL |
|---|---|---|---|
| hm2024 | H&M Group Annual and Sustainability Report 2024 | March 2025; FY2024 | https://hmgroup.com/wp-content/uploads/2025/03/HM-Group-Annual-and-sustainability-report-2024.pdf |
| patagonia2025 | Patagonia Work in Progress Report 2025 | November 2025; FY25 (May 2024–April 2025) | https://www.patagonia.com/media/pdf/patagonia-progress-report-2025.pdf |
| fr2024 | Fast Retailing Integrated Report 2024 sustainability chapter | 2024; FY2023 and FY2024 | https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en_06.pdf |
| frfinance2024 | Fast Retailing Integrated Report 2024 | 2024; FY2024 | https://www.fastretailing.com/eng/ir/library/pdf/ar2024_en.pdf |
| frclimate2025 | Fast Retailing Response to Climate Change | Current page; FY2025 | https://www.fastretailing.com/eng/sustainability/environment/climatechange.html |
| fla2025 | Patagonia Post-Accreditation Report 2025 | September 2025; 2023–2024 evaluations | https://www.fairlabor.org/wp-content/uploads/2025/09/Patagonia_Post-Accreditation-Report_2025.pdf |

---

## 6. Chart: Scope 1+2 Emissions Intensity (tCO₂e per million JPY, Fast Retailing)

Scale: 1 # = 0.02 tCO₂e/million JPY. Values: FY2021 = 0.131, FY2022 = 0.070, FY2023 = 0.033.

```
FY2021 ###### 0.131
FY2022 ###   0.070
FY2023 #    0.033
```

---

**Final Ranking:** 1st Patagonia (6.20), 2nd H&M (6.68), 3rd Fast Retailing (5.24). Note: H&M scores higher on composite due to transparency weight; Patagonia leads on social/ethics. Fast Retailing trails on transparency (no supplier list, no FLA accreditation). All scores are conservative where evidence is partial; missing data is not treated as zero performance but as an explicit gap.